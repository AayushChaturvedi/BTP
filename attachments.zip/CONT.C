#include<stdio.h>
#include<graphics.h>
#include<process.h>
#include <bios.h>
#include<string.h>
#include<stdlib.h>
#include<dos.h>
# define LS setlinestyle(SOLID_LINE,0,THICK_WIDTH);
# define TS1 settextstyle(SANS_SERIF_FONT,HORIZ_DIR,1);
# define TS2 settextstyle(DEFAULT_FONT,HORIZ_DIR,1);
# define TS3 settextstyle(DEFAULT_FONT,HORIZ_DIR,2);
# define VIEW setviewport(1,1,getmaxx()-1,getmaxy()-1,1);
main(int argc,char *argv[])
{
int CON=1,cg,rec1[16],rec[16],gd,gm,mode,i;
char c;
detectgraph(&gd,&gm);
initgraph(&gd,&gm,"c:\\tc\\");
if(strcmp(argv[1],"0")== 0){
for(i=0;i<16;++i){
rec[i]=rec1[i]=i;  }}
else{
for(i=0;i<16;++i){
rec[i]=0;
rec1[i]=15; }
}
while(CON)
{
VIEW;
LS;
setcolor(rec[1]);
rectangle(10,10,629,(getmaxy()/1.88+3.57));
setfillstyle(SOLID_FILL,rec1[15]);
floodfill(12,12,rec1[1]);
setcolor(rec[3]);
TS2;
outtextxy(275,(getmaxy()/56+11.43),"MENU  CARD");
outtextxy(275,(getmaxy()/56+16.43),"_________");
outtextxy(60,(getmaxy()/9.33+8.57),"TYPE OF CONVERTORS...");
outtextxy(70,(getmaxy()/7+11.43),"1. SINGLE PHASE HALF-WAVE CONTROLLED CONVERTOR");
outtextxy(70,(getmaxy()/5.6+14.29),"2. SINGLE PHASE HALF-WAVE CONTROLLED CONVERTOR WITH FWD");
outtextxy(70,(getmaxy()/4.67+17.14),"3. SINGLE PHASE HALF-CONTROLLED SYMMETRICAL BRIDGE CONVERTOR");
outtextxy(70,(getmaxy()/4+20),"4.SINGLE PHASE FULL-CONTROLLED BRIDGE CONVERTOR ");
outtextxy(70,(getmaxy()/3.5+22.86),"5.THREE PHASE HALF-WAVE CONVERTOR ");
outtextxy(70,(getmaxy()/3.11+25.71),"7.THREE PHASE HALF-CONTROLLED BRIDGE CONVERTOR                               ");
outtextxy(70,(getmaxy()/2.8+28.57),"8.THREE PHASE FULL-CONTROLLED BRIDGE CONVERTOR ");
outtextxy(70,(getmaxy()/2.55+31.43),"9.SINGLE PHASE HALF-CONTROLLED UNSYMMETRICAL BRIDGE CONVERTOR");
setcolor(rec[4]);
outtextxy(70,(getmaxy()/2.33+34.29),"------------ q  TO QUIT--------------------");
setcolor(rec[1]);
rectangle(10,(getmaxy()/2+30),630,(getmaxy()/1.85+84.29));
setfillstyle(SOLID_FILL,rec1[11]);
floodfill(12,(getmaxy()/2+32),rec1[1]);
setcolor(rec[0]);
rectangle(15,(getmaxy()/2+35),625,(getmaxy()/1.81+79.29));
setcolor(rec[0]);
rectangle(20,(getmaxy()/2.15+57.14),620,(getmaxy()/1.65+48.57));
outtextxy(100,(getmaxy()/1.87+52.86),"ENTER YOUR CHOICE:");
gotoxy(250,(getmaxy()/1.87+52.86));
setcolor(rec[4]);
again: c=getch();
if(c!='1'&&c!='2'&&c!='3'&&c!='4'&&c!='5'&&c!='7'&&c!='8'&&c!='9'&&c!='q')
goto again;
switch (c)
	{
	case '1':outtextxy(250,(getmaxy()/1.87+52.86)," 1");
		 sleep(1);
		 c=getch();
		 while(c!=13){
		 c=getch();}
		 mode=0;
		 serial(mode,'M');
		 if(strcmp(argv[1],"0")== 0)
		 execl("cas1.exe","cas1.exe","0",NULL);
		 else
		 execl("cas1.exe","cas1.exe","1",NULL);
		 break;
	case '2':outtextxy(250,(getmaxy()/1.87+52.86)," 2");
		 sleep(1);
		 c=getch();
		 while(c!=13){
		 c=getch();}
		 mode=1;
		 serial(mode,'M');
		 if(strcmp(argv[1],"0")== 0)
		 execl("cas2.exe","cas2.exe","0",NULL);
		 else
		 execl("cas2.exe","cas2.exe","1",NULL);
		 break;
	case '3':outtextxy(250,(getmaxy()/1.87+52.86)," 3");
		 sleep(1);
		 c=getch();
		 while(c!=13){
		 c=getch();}
		 mode=2;
		 serial(mode,'M');
		 if(strcmp(argv[1],"0")== 0)
		 execl("cas3.exe","cas3.exe","0",NULL);
		 else
		 execl("cas3.exe","cas3.exe","1",NULL);
		 break;
	case '4':outtextxy(250,(getmaxy()/1.87+52.86)," 4");
		 sleep(1);
		 c=getch();
		 while(c!=13){
		 c=getch();}
		 mode=3;
		 serial(mode,'M');
		 if(strcmp(argv[1],"0")== 0)
		 execl("cas5.exe","cas5.exe","0",NULL);
		 else
		 execl("cas5.exe","cas5.exe","1",NULL);
		 break;
	case '5':outtextxy(250,(getmaxy()/1.87+52.86)," 5");
		 sleep(1);
		 c=getch();
		 while(c!=13){
		 c=getch();}
		 mode=4;
		 serial(mode,'M');
		 if(strcmp(argv[1],"0")== 0)
		 execl("cas6.exe","cas6.exe","0",NULL);
		 else
		 execl("cas6.exe","cas6.exe","1",NULL);
		 break;
	case '9':outtextxy(250,(getmaxy()/1.87+52.86)," 9");
		 sleep(1);
		 c=getch();
		 while(c!=13){
		 c=getch();}
		 mode=8;
		 serial(mode,'M');
		 if(strcmp(argv[1],"0")== 0)
		 execl("cas4.exe","cas4.exe","0",NULL);
		 else
		 execl("cas4.exe","cas4.exe","1",NULL);
		 break;
	case '7':outtextxy(250,(getmaxy()/1.87+52.86)," 7");
		 sleep(1);
		 c=getch();
		 while(c!=13){
		 c=getch();}
		 mode=6;
		 serial(mode,'M');
		 if(strcmp(argv[1],"0")== 0)
		 execl("cas7.exe","cas7.exe","0",NULL);
		 else
		 execl("cas7.exe","cas7.exe","1",NULL);
		 break;
	case '8':outtextxy(250,(getmaxy()/1.87+52.86)," 8");
		 sleep(1);
	 c=getch();
		 while(c!=13){
		 c=getch();}
		 mode=7;
		 serial(mode,'M');
		 if(strcmp(argv[1],"0")== 0 )
		 execl("cas8.exe","cas8.exe","0",NULL);
		 else
		 execl("cas8.exe","cas8.exe","1",NULL);
		 break;
	case 'q':outtextxy(250,(getmaxy()/1.87+52.86)," q");
		 CON=0;
		 break;
	}
}
}
serial(int x,int ch)
{
	bioscom(1,ch,0);
	bioscom(1,x,0);
}