#include<dos.h>
#include<stdio.h>
#include<stdlib.h>
#include<bios.h>
#include<conio.h>
int x,y,z,ch;
main()
	{
		x=0xa7;
		y='M';
		bioscom(0,x,0);
		bioscom(3,y,0);
		printf("\n %x     %x",x,y);
		ch='A';
		for(;;)
		{
			if(kbhit())
			{
				ch=getche();
				printf("   %x \n ",ch);
			}
			switch(ch)
			{
				case's'	:exit(1);
					 break;
				default	:bioscom(1,ch,0);
			}
		}
	}

