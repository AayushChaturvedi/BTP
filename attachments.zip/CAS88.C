# include <graphics.h>
# include <math.h>
# include <conio.h>
# include <stdio.h>
# include <stdlib.h>
#include<process.h>
#include<string.h>
# define VIEW1 setviewport(0,0,239,(getmaxy()/2.04)-5.86,1);
# define VIEW2 setviewport(0,(getmaxy()/2.04)-4.86,239,getmaxy()-1,1);
# define VIEW3 setviewport(240,0,639,getmaxy()-1,1);
# define VIEW4 setviewport(150,getmaxy()/1.11-34,200,getmaxy()/1.10-27.43,1);
# define VIEW5 setviewport(180,getmaxy()/1.07-31.14,215,getmaxy()/1.06-24.57,1);
# define VIEW6 setviewport(180,getmaxy()/1.061-22.57,215,getmaxy()/1.053-16,1);
float vc,l,r,vin,data;
int f_angle,cond_ang,fwd_ang,xx,yy,rec[16],rec1[16],change,arrow[10],v110,cg;
int f_angle_lb,f_angle_hb,xxx;
unsigned size3;
void *buf3;
void help();

main(int argc,char *argv[])
{
	int  type_con[30],scale_c,gd,gm;
	int  angle,volt,volt_y,volt_y1,current_y,CONT=1,volt_yy,volt_res,volt_ind,volt_thy,kkk;
	int i_int,i_fnl,kk,MOR=1,MODE,peak,peak_l,peak_p,ya,yry,yrb,yyb,yyr,ybr,yby,vc_m,i,v270,v375;
	char c;
	float  tau,wtau,phi,z,ww,f_ang,j;
	float abc,def,pi,rad,ang,current;
	unsigned size,size1;
	void *buf,*buf1;
        detectgraph(&gd,&gm);
		initgraph(&gd,&gm,"c:\\tc\\");
                if(strcmp(argv[1],"0")==0){
		cg=0;
		for(i=0;i<16;++i){
		rec[i]=rec1[i]=i;  }
		}
		else{
		cg=1;
		for(i=0;i<16;++i){
		rec[i]=0;
		rec1[i]=15; }
		}
	change=0;
        v110=getmaxy()/5.28+19.14;
	v375=getmaxy()/1.26-5.57;
	v270=getmaxy()/1.76-2.57;
	pi=22.0/7.0;
	rad=pi/180.0;
	frame();
	type_con[0]=type_con[2]=type_con[8]=type_con[12]=type_con[22]=type_con[26]=type_con[28]=75;
	type_con[4]=type_con[10]=type_con[14]=type_con[18]=65;
	type_con[6]=type_con[24]=85;
	type_con[16]=type_con[20]=70;
	type_con[1]=getmaxy()/3.5+2.857;
	type_con[3]=type_con[5]=type_con[7]=type_con[11]=getmaxy()/7.368+9.857;
	type_con[9]=type_con[13]=type_con[15]=type_con[17]=type_con[21]=type_con[23]=type_con[25]=type_con[27]=getmaxy()/10+7;
	type_con[19]=getmaxy()/11.67+3.857;
	type_con[29]=getmaxy()/12.174+1.57;
	VIEW1;
	setcolor(rec[5]);
	drawpoly(sizeof(type_con)/(2*sizeof(int)),type_con);
	size=imagesize(60,getmaxy()/12.174+0.57,90,getmaxy()/3.5+2.857);
	buf=malloc(size);
	getimage(60,getmaxy()/12.174+0.57,90,getmaxy()/3.5+2.857,buf);
	putimage(100,getmaxy()/12.174+1.57,buf,COPY_PUT);
	putimage(130,getmaxy()/12.174+1.57,buf,COPY_PUT);
	getimage(60,getmaxy()/12.174+0.57,90,getmaxy()/6.51+17.286,buf);
	putimage(60,getmaxy()/3.5+2.857,buf,COPY_PUT);
	putimage(100,getmaxy()/3.5+2.857,buf,COPY_PUT);
	putimage(130,getmaxy()/3.5+2.857,buf,COPY_PUT);
	line(75,getmaxy()/12.174+1.57,170,getmaxy()/12.174+1.57);
	line(75,getmaxy()/6.22+7.86,15,getmaxy()/6.22+7.86);
	line(115,getmaxy()/4.67+7.143,15,getmaxy()/4.67+7.143);
	line(145,getmaxy()/3.5+2.857,15,getmaxy()/3.5+2.857);
	line(200,getmaxy()/2.8+19.57,75,getmaxy()/2.8+19.57);
	outtextxy(10,getmaxy()/6.22+2.86,"R");
	outtextxy(10,getmaxy()/4.67+2.143,"Y");
	outtextxy(10,getmaxy()/3.5-2.143,"B");
	scale_c=ceil(getmaxy()/(-93.33)+8.143) ;
	size3=imagesize(0,0,240,(getmaxy()/2.04)-5.86);
		buf3=malloc(size3);
getimage(0,0,239,(getmaxy()/2.04)-5.86,buf3);
	while(MOR)
	{       if(change==0)
		value();
		if(change==2)
		goto NEXT1;
		if(change==3){
		c=27;
		goto NEXT2;}
		if(l==0 & r==0)
			{	CONT=0;
				return;
			}
		else
			{
				CONT=1;
				if(l==0 & r!=0)
					MODE=1;
				else
				{
					if(l!=0 & r==0)
						MODE=2;
					else
						MODE=3;
				}
			}
              VIEW3;
		peak_l=(1.732*vin)/(getmaxy()/(-46.67)+16.286);
		peak_p=vin/(getmaxy()/(-46.67)+16.286);
		vc_m=vc/(getmaxy()/(-46.67)+16.286);
		setcolor(rec[9]);
		line(10,v110,395,v110);
		line(10,v270,395,v270);
		line(10,v375,395,v375);
		line(10,5,10,475);
		for(i=0;i<=360;++i)
		{	j=i*rad;
			yry=v110-peak_l*sin(j);
			yrb=v110-peak_l*sin(j-pi/3);
			yyb=v110-peak_l*sin(j-2*pi/3);
			yyr=v110-peak_l*sin(j-pi);
			ybr=v110-peak_l*sin(j-4*pi/3);
			yby=v110-peak_l*sin(j-5*pi/3);
			putpixel(10+i,yry,rec[9]);
			putpixel(10+i,yrb,rec[9]);
			putpixel(10+i,yyb,rec[9]);
			putpixel(10+i,yyr,rec[9]);
			putpixel(10+i,ybr,rec[9]);
			putpixel(10+i,yby,rec[9]);
		}
		volt_yy=v110-vc_m;
		line(10,volt_yy,395,volt_yy);
		kk=60;
		arrowpos(kk);
                xxx=f_angle*6.144*pow(10,3)/(18*12);
		f_angle_lb=(0x00ff)&(xxx);
		f_angle_hb=(0xff00)&(xxx);
		f_angle_hb=f_angle_hb>>8;
		serial(f_angle_lb,'G');
		serial(f_angle_hb,'L');
		serial(0,'R');
		kkk=1;
		angle=f_angle;
		switch(MODE)
		{
		case 1: j=angle*rad;
			current=(1.732*vin*sin(j)-vc)/r;
			if(f_angle<60)
			current=0;
			break;
		case 2:	j=(angle+2)*rad;
			f_ang=f_angle*rad;
			ww=2.0*pi*50.0;
			current=1.732*vin*(cos(f_ang-pi/3)-cos(j-pi/3))/(ww*l)+vc/(ww*l)*(f_ang-j);
			if(f_angle<60)
			current=0;
			break;
		case 3:	j=(angle+2)*rad;
			f_ang=f_angle*rad;
			ww=2.0*pi*50.0;
			z=sqrt(r*r+(ww*l)*(ww*l));
			phi=acos(r/z);
			tau=l/r;
			wtau=ww*tau;
			current=(1.732*vin/z)*(sin(j-phi)-exp(-(j-f_ang)/wtau)*sin(f_ang-phi))-vc/r*(1-exp(-(j-f_ang)/wtau));
                        if(f_angle<60)
			current=0;
			break;
			}

                        if(current>0)
			{
                                switch(MODE)
				{
				case 1:	i_int=0;
					break;
				case 2:
				break;
				case 3:	abc=(vin/z)*sin(f_ang-phi)+(vin/z)*(sin(f_ang-phi)-sin((pi/3)+f_ang-phi))/(exp(-(2*pi/3)/wtau)-1);
					i_int=abc-(vc/r);
					if(i_int<0)
						i_int=0;
					break;
				}
                                while(CONT)
				{	j=angle*rad;
                                        switch(MODE)
					{
					case 1:	current=(1.732*vin*sin(j)-vc)/r;
						current_y=ceil(v110-current/scale_c);
						volt_res=v270-current*r/(getmaxy()/(-46.67)+16.286);
						putpixel(10+angle,volt_res,rec[2]);
						putpixel(10+angle,volt_res+1,rec[2]);
						putpixel(10+(angle+60),volt_res+1,rec[2]);
						putpixel(10+(angle+60),volt_res,rec[2]);
						putpixel(10+(angle+120),volt_res+1,rec[2]);
						putpixel(10+(angle+120),volt_res,rec[2]);
						putpixel(10+(angle+180),volt_res+1,rec[2]);
						putpixel(10+(angle+180),volt_res,rec[2]);
						putpixel(10+(angle+240),volt_res+1,rec[2]);
						putpixel(10+(angle+240),volt_res,rec[2]);
						putpixel(10+(angle-60),volt_res+1,rec[2]);
						putpixel(10+(angle-60),volt_res,rec[2]);
						if(angle>=120)
						{
						putpixel(10+(angle-120),volt_res+1,rec[2]);
						putpixel(10+(angle-120),volt_res,rec[2]);
						}
						if(angle>=180)
						{
						putpixel(10+(angle-180),volt_res+1,rec[2]);
						putpixel(10+(angle-180),volt_res,rec[2]);
						}
						if(angle>=240)
						{
						putpixel(10+(angle-240),volt_res+1,rec[2]);
						putpixel(10+(angle-240),volt_res,rec[2]);
						}
						if(kkk==1)
							{	setcolor(rec[2]);
								line(10+angle,v270,10+angle,volt_res+1);
								line(10+(angle+60),v270,10+(angle+60),volt_res+1);
								line(10+(angle+120),v270,10+(angle+120),volt_res+1);
								line(10+(angle+180),v270,10+(angle+180),volt_res+1);
								line(10+(angle+240),v270,10+(angle+240),volt_res+1);
								line(10+(angle-60),v270,10+(angle-60),volt_res+1);
								if(angle>=120)
								{
								line(10+(angle-120),v270,10+(angle-120),volt_res+1);
								}
								if(angle>=180)
								{
								line(10+(angle-180),v270,10+(angle-180),volt_res+1);
								}
								if(angle>=240)
								{
								line(10+(angle-240),v270,10+(angle-240),volt_res+1);
								}
								kkk=0;
							}
						else
							kkk=1;

                                                cond_ang=angle-f_angle;
						break;
					case 2:current=vin*(cos(f_ang)-cos(j))/(ww*l)+vc/(ww*l)*(f_ang-j);
					       current_y=ceil(v110-current/scale_c);
					       volt_ind=v270-(peak_l*sin(j)-vc_m);
						putpixel(10+angle,volt_ind,rec[3]);
						putpixel(10+angle,volt_ind+1,rec[3]);
						putpixel(10+(angle+60),volt_ind,rec[3]);
						putpixel(10+(angle+60),volt_ind+1,rec[3]);
                                                putpixel(10+(angle+120),volt_ind,rec[3]);
						putpixel(10+(angle+120),volt_ind+1,rec[3]);
						putpixel(10+(angle+180),volt_ind,rec[3]);
						putpixel(10+(angle+180),volt_ind+1,rec[3]);
						putpixel(10+(angle+240),volt_ind,rec[3]);
						    putpixel(10+(angle+240),volt_ind+1,rec[3]);
						    putpixel(10+(angle-60),volt_ind,rec[3]);
						putpixel(10+(angle-60),volt_ind+1,rec[3]);
						if(angle>=120)
						{
						    putpixel(10+(angle-120),volt_ind,rec[3]);
						    putpixel(10+(angle-120),volt_ind+1,rec[3]);
						}
						if(angle>=180)
						{
						    putpixel(10+(angle-180),volt_ind,rec[3]);
						    putpixel(10+(angle-180),volt_ind+1,rec[3]);
						}
						if(angle>=240)
						{
						    putpixel(10+(angle-240),volt_ind,rec[3]);
						    putpixel(10+(angle-240),volt_ind+1,rec[3]);
						}
						if(kkk==1)
							{       setcolor(rec[3]);
								line(10+angle,v270,10+angle,volt_ind+1);
								line(10+(angle+60),v270,10+(angle+60),volt_ind+1);
								line(10+(angle+120),v270,10+(angle+120),volt_ind+1);
								line(10+(angle+180),v270,10+(angle+180),volt_ind+1);
								line(10+(angle+240),v270,10+(angle+240),volt_ind+1);
								line(10+(angle-60),v270,10+(angle-60),volt_ind+1);
								if(angle>=120)
								line(10+(angle-120),v270,10+(angle-120),volt_ind+1);
								if(angle>=180)
								line(10+(angle-180),v270,10+(angle-120),volt_ind+1);
								if(angle>=240)
								line(10+(angle-240),v270,10+(angle-240),volt_ind+1);
								kkk=0;
							}
						else
							kkk=1;
						cond_ang=angle-f_angle;
						break;
					case 3:    	current=(vin/z)*(sin(j-phi)-exp(-(j-f_ang)/wtau)*sin(f_ang-phi))-vc/r*(1-exp(-(j-f_ang)/wtau))+i_int*exp(-(j-f_ang)/wtau);
							current_y=ceil(v110-current/scale_c);
							volt_res=v270-current*r/(getmaxy()/(-46.67)+16.286);
							volt=v270-peak_l*sin(j)+vc_m ;
                                                        volt_ind=v270-(peak_l*sin(j)-vc_m)+current*r/(getmaxy()/(-46.67)+16.286);
                                                        putpixel(10+angle,volt_res,rec[2]);
							putpixel(10+angle,volt_res+1,rec[2]);
							putpixel(10+(angle+60),volt_res,rec[2]);
							putpixel(10+(angle+60),volt_res+1,rec[2]);
							putpixel(10+(angle+120),volt_res,rec[2]);
							putpixel(10+(angle+120),volt_res+1,rec[2]);
							putpixel(10+(angle+180),volt_res,rec[2]);
							putpixel(10+(angle+180),volt_res+1,rec[2]);
							putpixel(10+(angle+240),volt_res,rec[2]);
							putpixel(10+(angle+240),volt_res+1,rec[2]);
							putpixel(10+(angle-60),volt_res,rec[2]);
							putpixel(10+(angle-60),volt_res+1,rec[2]);
							if(angle>120)
							{
							putpixel(10+(angle-120),volt,rec[4]);
                                                        putpixel(10+(angle-120),volt_ind,rec[3]);
							putpixel(10+(angle-120),volt_ind+1,rec[3]);
							putpixel(10+(angle-120),volt_res,rec[2]);
							putpixel(10+(angle-120),volt_res+1,rec[2]);
							}
							if(angle>180)
							{
							putpixel(10+(angle-180),volt,rec[4]);
							putpixel(10+(angle-180),volt_ind,rec[3]);
							putpixel(10+(angle-180),volt_ind+1,rec[3]);
							putpixel(10+(angle-180),volt_res,rec[2]);
							putpixel(10+(angle-180),volt_res+1,rec[2]);
							}
							if(angle>240)
							{
							putpixel(10+(angle-240),volt,rec[4]);
							putpixel(10+(angle-240),volt_ind,rec[3]);
							putpixel(10+(angle-240),volt_ind+1,rec[3]);
							putpixel(10+(angle-240),volt_res,rec[2]);
							putpixel(10+(angle-240),volt_res+1,rec[2]);
							}
							putpixel(10+angle,volt,rec[4]);
							putpixel(70+angle,volt,rec[4]);
							putpixel(130+angle,volt,rec[4]);
							putpixel(190+angle,volt,rec[4]);
							putpixel(250+angle,volt,rec[4]);
							putpixel(10+(angle-60),volt,rec[4]);
							/*VOLTAGE ACROSS INDUCTANCE*/

                                                        putpixel(10+angle,volt_ind,rec[3]);
							putpixel(10+angle,volt_ind+1,rec[3]);
							putpixel(10+(angle+240),volt_ind,rec[3]);
							putpixel(10+(angle+240),volt_ind+1,rec[3]);
							putpixel(10+(angle+60),volt_ind,rec[3]);
							putpixel(10+(angle+60),volt_ind+1,rec[3]);
							putpixel(10+(angle+180),volt_ind,rec[3]);
							putpixel(10+(angle+180),volt_ind+1,rec[3]);
							putpixel(10+(angle+120),volt_ind,rec[3]);
							putpixel(10+(angle+120),volt_ind+1,rec[3]);
							putpixel(10+(angle-60),volt_ind,rec[3]);
							putpixel(10+(angle-60),volt_ind+1,rec[3]);
							if(kkk==1)
							{	setcolor(rec[2]);
								line(10+angle,v270,10+angle,volt_res+1);
								line(10+(angle+60),v270,10+(angle+60),volt_res+1);
								line(10+(angle+120),v270,10+(angle+120),volt_res+1);
								line(10+(angle+180),v270,10+(angle+180),volt_res+1);
								line(10+(angle+240),v270,10+(angle+240),volt_res+1);
								line(10+(angle-60),v270,10+(angle-60),volt_res+1);
								if(angle>=120)
								line(10+(angle-120),v270,10+(angle-120),volt_res+1);
								if(angle>=180)
								line(10+(angle-180),v270,10+(angle-180),volt_res+1);
								if(angle>=240)
								line(10+(angle-240),v270,10+(angle-240),volt_res+1);
								kkk=0;
							}
							else
							{       setcolor(rec[3]);
								line(10+angle,v270,10+angle,volt_ind+1);
								line(10+(angle+60),v270,10+(angle+60),volt_ind+1);
								line(10+(angle+120),v270,10+(angle+120),volt_ind+1);
								line(10+(angle+180),v270,10+(angle+180),volt_ind+1);
								line(10+(angle+240),v270,10+(angle+240),volt_ind+1);
								line(10+(angle-60),v270,10+(angle-60),volt_ind+1);
								if(angle>=120)
								line(10+(angle-120),v270,10+(angle-120),volt_ind+1);
								if(angle>=180)
								line(10+(angle-180),v270,10+(angle-180),volt_ind+1);
								if(angle>=240)
								line(10+(angle-240),v270,10+(angle-240),volt_ind+1);
								kkk=1;
							}
							cond_ang=angle-f_angle;
						break;
					}
					putpixel(10+angle,current_y,rec[0]);
					putpixel(10+angle,current_y+1,rec[0]);
					putpixel(10+(angle+60),current_y,rec[0]);
					putpixel(10+(angle+60),current_y+1,rec[0]);
                                        putpixel(10+(angle+120),current_y,rec[0]);
					putpixel(10+(angle+120),current_y+1,rec[0]);
					putpixel(10+(angle+180),current_y,rec[0]);
					putpixel(10+(angle+180),current_y+1,rec[0]);
					putpixel(10+(angle+240),current_y,rec[0]);
					putpixel(10+(angle+240),current_y+1,rec[0]);
					putpixel(10+(angle-60),current_y,rec[0]);
					putpixel(10+(angle-60),current_y+1,rec[0]);
						 if(angle>=120)
						 {
						     putpixel(10+(angle-120),current_y,rec[0]);
						     putpixel(10+(angle-120),current_y+1,rec[0]);
						 }
					      if(angle>=180)
						 {
						     putpixel(10+(angle-180),current_y,rec[0]);
						     putpixel(10+(angle-180),current_y+1,rec[0]);
						 }
					       if(angle>=240)
						 {
						     putpixel(10+(angle-240),current_y,rec[0]);
						     putpixel(10+(angle-240),current_y+1,rec[0]);
						 }
					if(current>=0&&(angle-60)==f_angle)
					{angle=angle-1;
					CONT=0;
					}
					if(current<0)
					{angle=angle-1;
					CONT=0;
					}
				angle=angle+1;
				if (angle==360)CONT=0;
				}

				volt_yy=v110-vc_m;
					ang=angle*rad;
					f_ang=f_angle*rad;
                                       volt_y1=v110-peak_l*sin(f_ang);
				 /* VOLTAGE  OUTPUT   */
				  for(i=f_angle;i<=angle;i++)
					{
					j=i*rad;
					 volt_y=v110-peak_l*sin(j);
					 putpixel(10+i,volt_y,rec[4]);
					 putpixel(10+i,volt_y+1,rec[4]);
					 putpixel(70+i,volt_y,rec[4]);
					 putpixel(70+i,volt_y+1,rec[4]);
					 putpixel(130+i,volt_y,rec[4]);
					 putpixel(130+i,volt_y+1,rec[4]);
					 putpixel(190+i,volt_y,rec[4]);
					 putpixel(190+i,volt_y+1,rec[4]);
					 putpixel(250+i,volt_y,rec[4]);
					 putpixel(250+i,volt_y+1,rec[4]);
					 putpixel(10+(i-60),volt_y,rec[4]);
					 putpixel(10+(i-60),volt_y+1,rec[4]);
					 if(i<120){
					 putpixel(310+i,volt_y,rec[4]);
					 putpixel(310+i,volt_y+1,rec[4]);}
					 if(i>120){
					 putpixel(10+(i-120),volt_y,rec[4]);
					 putpixel(10+(i-120),volt_y+1,rec[4]);}
					 if(i>180){
					 putpixel(10+(i-180),volt_y,rec[4]);
					 putpixel(10+(i-180),volt_y+1,rec[4]);}
					 if(i>240){
					 putpixel(10+(i-240),volt_y,rec[4]);
					 putpixel(10+(i-240),volt_y+1,rec[4]);}
					}
                                       setcolor(rec[4]);

					if((angle-60)!=f_angle)
					{
                                        line(10+f_angle,volt_yy,10+f_angle,volt_y1);
					line(70+f_angle,volt_yy,70+f_angle,volt_y1);
					line(130+f_angle,volt_yy,130+f_angle,volt_y1);
					line(190+f_angle,volt_yy,190+f_angle,volt_y1);
					line(250+f_angle,volt_yy,250+f_angle,volt_y1);
					line(10+(f_angle-60),volt_yy,10+(f_angle-60),volt_y1);
					if(f_angle>=120)
					line(10+(f_angle-120),volt_yy,10+(f_angle-120),volt_y1);
					if(f_angle>=180)
					line(10+(f_angle-180),volt_yy,10+(f_angle-180),volt_y1);
					if(f_angle>=240)
					line(10+(f_angle-240),volt_yy,10+(f_angle-240),volt_y1);
					line(10+angle,volt_yy,70+f_angle,volt_yy);
					line(130+angle,volt_yy,190+f_angle,volt_yy);
					line(70+angle,volt_yy,130+f_angle,volt_yy);
					line(190+angle,volt_yy,250+f_angle,volt_yy);
					line(250+angle,volt_yy,310+f_angle,volt_yy);
					line(10+(angle-60),volt_yy,10+f_angle,volt_yy);
					if(angle>=120)
					line(10+(angle-120),volt_yy,10+(f_angle-60),volt_yy);
					if(angle>=180)
					line(10+(angle-180),volt_yy,10+(f_angle-120),volt_yy);
					if(angle>=240)
					line(10+(angle-240),volt_yy,10+(f_angle-180),volt_yy);
					if(angle>=300)
					line(10+(angle-300),volt_yy,10+(f_angle-240),volt_yy);
					line(10+angle,volt_yy,10+angle,volt_y);
					line(70+angle,volt_yy,70+angle,volt_y);
					line(130+angle,volt_yy,130+angle,volt_y);
					line(190+angle,volt_yy,190+angle,volt_y);
					line(250+angle,volt_yy,250+angle,volt_y);
					line(10+(angle-60),volt_yy,10+(angle-60),volt_y);
					if(angle>=120)
					line(10+(angle-120),volt_yy,10+(angle-120),volt_y);
					if(angle>=180)
					line(10+(angle-180),volt_yy,10+(angle-180),volt_y);
					if(angle>=240)
					line(10+(angle-240),volt_yy,10+(angle-240),volt_y);
					}
					if((angle-60)==f_angle)
					{
					line(10+angle,volt_y,70+f_angle,volt_y1);
					line(130+angle,volt_y,190+f_angle,volt_y1);
					line(70+angle,volt_y,130+f_angle,volt_y1);
					line(190+angle,volt_y,250+f_angle,volt_y1);
					line(250+angle,volt_y,310+f_angle,volt_y1);
					line(10+(angle-60),volt_y,10+f_angle,volt_y1);
					if(angle>=120)
					line(10+(angle-120),volt_y,10+(f_angle-60),volt_y1);
					if(angle>=180)
					line(10+(angle-180),volt_y,10+(f_angle-120),volt_y1);
					if(angle>=240)
					line(10+(angle-240),volt_y,10+(f_angle-180),volt_y1);
					if(angle>=300)
					line(10+(angle-300),volt_y,10+(f_angle-240),volt_y1);
					}

				 /*VOLTAGE  ACROSS  THYRISTOR    */
				setcolor(rec[5]);
                                        volt_thy=v375;
						line(10+f_angle,volt_thy,10+angle,volt_thy);
						line(70+f_angle,volt_thy,70+angle,volt_thy);
						ya=v375-(peak_p*sin(ang-pi/6)-vc_m) ;
						if(angle!=60+f_angle)
						{
						line(10+angle,volt_thy,10+angle,ya);
						   for(i=angle;i<=60+f_angle;i++)
						   {
						    j=i*rad;
						    volt_thy=v375-(peak_p*sin(j-pi/6)-vc_m);
						    putpixel(10+i,volt_thy,rec[5]);
						    putpixel(10+i,volt_thy+1,rec[5]);
						   }
						}
						line(10+(f_angle+60),volt_thy,10+(f_angle+60),v375);
						ya=v375-(peak_p*sin(ang+pi/6)-vc_m) ;
						volt_thy=v375;
						if(angle!=60+f_angle)
						{
						line(70+angle,v375,70+angle,ya);
						   for(i=60+angle;i<=120+f_angle;i++)
						   {
						    j=i*rad;
						    volt_thy=v375-(peak_p*sin(j-pi/6)-vc_m);
						    putpixel(10+i,volt_thy,rec[5]);
						    putpixel(10+i,volt_thy+1,rec[5]);
						   }
						}
						   yry=v375-peak_l*sin(f_ang+2*pi/3);
						   line(130+f_angle,volt_thy,130+f_angle,yry);
						   for(i=120+f_angle;i<=angle+120;i++)
						   {
						    j=i*rad;
						    volt_thy=v375-peak_l*sin(j);
						    putpixel(10+i,volt_thy,rec[5]);
						    putpixel(10+i,volt_thy+1,rec[5]);
						   }
						   ya=v375-(peak_p*sin(ang+pi/2)-vc_m);
						   if(angle!=60+f_angle)
						   {
						   line(130+angle,volt_thy,130+angle,ya);
						   for(i=(angle+120);i<=180+f_angle;i++)
						   {
						    j=i*rad;
						    volt_thy=v375-(peak_p*sin(j-pi/6)-vc_m);
						    putpixel(10+i,volt_thy,rec[5]);
						    putpixel(10+i,volt_thy+1,rec[5]);
						   }
						   }
						   yry=v375-peak_l*sin(f_ang+pi);
						   line(190+f_angle,volt_thy,190+f_angle,yry);
						   for(i=180+f_angle;i<=180+angle;i++)
						   {
						    j=i*rad;
						    volt_thy=v375-peak_l*sin(j);
						    putpixel(10+i,volt_thy,rec[5]);
						    putpixel(10+i,volt_thy+1,rec[5]);
						   }
						   ya=v375-(peak_p*sin(ang+5*pi/6)-vc_m) ;
						if(angle!=60+f_angle)
						{
						line(190+angle,volt_thy,190+angle,ya);
						   for(i=180+angle;i<=240+f_angle;i++)
						   {
						    j=i*rad;
						    volt_thy=v375-(peak_p*sin(j-pi/6)-vc_m);
						    putpixel(10+i,volt_thy,rec[5]);
						    putpixel(10+i,volt_thy+1,rec[5]);
						   }
						}
						yrb=v375-peak_l*sin(f_ang+pi);
						line(250+f_angle,volt_thy,250+f_angle,yrb);
						   for(i=240+f_angle;i<=300+angle;i++)
						   {
						    j=i*rad;
						    volt_thy=v375-peak_l*sin(j-pi/3);
						    putpixel(10+i,volt_thy,rec[5]);
						    putpixel(10+i,volt_thy+1,rec[5]);
						   }

						    for(i=f_angle-240;i<=angle-240;i++)
						     {
						      j=i*rad;
						      if(i<0) {
						      i=0 ;
						      continue;}
							 volt_thy=v375-peak_l*sin(j);
							 putpixel(10+i,volt_thy,rec[5]);
							  putpixel(10+i,volt_thy+1,rec[5]);
						     }
						     ya=v375-(peak_p*sin(ang-3*pi/2)-vc_m);
						      if(angle!=60+f_angle)
						       {
							 if(angle>240)
							 line(10+(angle-240),volt_thy,10+(angle-240),ya);
							 for(i=(angle-240);i<=f_angle-180;i++)
							 {
							 j=i*rad;
                                                         if(i<0) {
							    i=0 ;
							  continue;}
							 volt_thy=v375-(peak_p*sin(j-pi/6)-vc_m);
							 putpixel(10+i,volt_thy,rec[5]);
							  putpixel(10+i,volt_thy+1,rec[5]);
							 }

						       }
						      yry=v375-peak_l*sin(f_ang-pi);
						      if(f_angle>=180)
						      line(10+(f_angle-180),volt_thy,10+(f_angle-180),yry);
						      for(i=f_angle-180;i<=angle-180;i++)
						     {
						      j=i*rad;
						      if(i<0) {
						      i=0 ;
						      continue;}
							 volt_thy=v375-peak_l*sin(j);
							 putpixel(10+i,volt_thy,rec[5]);
							  putpixel(10+i,volt_thy+1,rec[5]);
						     }
						     ya=v375-(peak_p*sin(ang-7*pi/6)-vc_m);
						      if(angle!=60+f_angle)
						       {
							 if(angle>180)
							 line(10+(angle-180),volt_thy,10+(angle-180),ya);
							 for(i=(angle-180);i<=f_angle-120;i++)
							 {
							 j=i*rad;
                                                         if(i<0) {
							    i=0 ;
							  continue;}
							 volt_thy=v375-(peak_p*sin(j-pi/6)-vc_m);
							 putpixel(10+i,volt_thy,rec[5]);
							  putpixel(10+i,volt_thy+1,rec[5]);
							 }

						       }
						      yrb=v375-peak_l*sin(f_ang-pi);
						      if(f_angle>=120)
						      line(10+(f_angle-120),volt_thy,10+(f_angle-120),yrb);
						     for(i=f_angle-120;i<=angle-120;i++)
						     {
						      j=i*rad;
						      if(i<0) {
						      i=0 ;
						      continue;}
							 volt_thy=v375-peak_l*sin(j-pi/3);
							 putpixel(10+i,volt_thy,rec[5]);
							  putpixel(10+i,volt_thy+1,rec[5]);
						     }
						     ya=v375-(peak_p*sin(ang-5*pi/6)-vc_m);
						      if(angle!=60+f_angle)
						       {
							 if(angle>120)
							 line(10+(angle-120),volt_thy,10+(angle-120),ya);
							 for(i=(angle-120);i<=f_angle-60;i++)
							 {
							 j=i*rad;
							 if(i<0){
							 i=0;
							 continue;}
							 volt_thy=v375-(peak_p*sin(j-pi/6)-vc_m);
							 putpixel(10+i,volt_thy,rec[5]);
							  putpixel(10+i,volt_thy+1,rec[5]);
							 }

						       }
						       yrb=v375-peak_l*sin(f_ang-2*pi/3);
						       line(10+(f_angle-60),volt_thy,10+(f_angle-60),yrb);
                                                       for(i=f_angle-60;i<=angle-60;i++)
						     {
						      j=i*rad;
                                                      if(i<0) {
						      i=0 ;
						      continue;}
							 volt_thy=v375-peak_l*sin(j-pi/3);
							 putpixel(10+i,volt_thy,rec[5]);
							  putpixel(10+i,volt_thy+1,rec[5]);
						     }
						     ya=v375-(peak_p*sin(ang-pi/2)-vc_m);
						      if(angle!=60+f_angle)
						       {
							 line(10+(angle-60),volt_thy,10+(angle-60),ya);
							 for(i=(angle-60);i<=f_angle;i++)
							 {
							 j=i*rad;
                                                         if(i<0) {
							 i=0 ;
							   continue;}
							 volt_thy=v375-(peak_p*sin(j-pi/6)-vc_m);
							 putpixel(10+i,volt_thy,rec[5]);
							  putpixel(10+i,volt_thy+1,rec[5]);
							 }

						       }
						       line(10+f_angle,volt_thy,10+f_angle,v375);
				switch(MODE)
				{
				case 1:
					current=(1.732*vin*sin(f_ang)-vc)/r;
					current_y=v110-current/(getmaxy()/(-93.33)+8.143);
					setcolor(rec[0]);
					line(10+f_angle+1,v110,10+f_angle+1,current_y);
					line(70+f_angle+1,v110,70+f_angle+1,current_y);
					line(130+f_angle+1,v110,130+f_angle+1,current_y);
					line(190+f_angle+1,v110,190+f_angle+1,current_y);
					line(250+f_angle+1,v110,250+f_angle+1,current_y);
					line(11+(f_angle-60),v110,11+(f_angle-60),current_y);
					if(f_angle>=120)
					line(11+(f_angle-120),v110,11+(f_angle-120),current_y);
					if(f_angle>=180)
					line(11+(f_angle-180),v110,11+(f_angle-180),current_y);
					if(f_angle>=240)
					line(11+(f_angle-240),v110,11+(f_angle-240),current_y);
					  break;
				case 2:
				case 3:
					break;
				}
                                VIEW2;
				setcolor(rec[6]);
				outtextxy(30,(getmaxy()/2.22-25),"CONDUCTION ANGLE = ");
				outtextxy(10,(getmaxy()/2.24-14.29),"FREE WHEELING ANGLE =");
				VIEW5;
				f_ang_prn(cond_ang);
				VIEW6;
				f_ang_prn(fwd_ang);
			}
                else
			{
				setcolor(rec[4]);
				line(10,volt_yy,10+360,volt_yy);
				line(10,volt_yy+1,10+360,volt_yy+1);
                                setcolor(rec[0]);
				line(10,v110,10+360,v110);
				line(10,(getmaxy()/5.28+20.14),10+360,(getmaxy()/5.28+20.14));
				switch(MODE)
				{
				case 1:	setcolor(rec[2]);
					line(10,v270,10+360,v270);
					line(10,(getmaxy()/1.76-1.57),10+360,(getmaxy()/1.76-1.57));
					break;
				case 2: setcolor(rec[3]);
					line(10,v270,10+360,v270);
					line(10,(getmaxy()/1.76-3.57),10+360,(getmaxy()/1.76-3.57));
					break;
				case 3:	setcolor(rec[2]);
					line(10,v270,10+360,v270);
					line(10,(getmaxy()/1.76-1.57),10+360,(getmaxy()/1.76-1.57));
                                        setcolor(rec[3]);
					line(10,v270,10+360,v270);
					line(10,(getmaxy()/1.76-3.57),10+360,(getmaxy()/1.76-3.57));
					break;
				}
				setcolor(rec[5]);
				for(i=0;i<=360;++i)
				{	j=i*rad;
					if(f_angle<60)
					volt_thy=v375-peak_l*sin(j-pi/3);
					else{
					      ya=peak_p*sin(j-pi/6);
					volt_thy=v375-(ya-vc_m);}
					putpixel(10+i,volt_thy,rec[5]);
					putpixel(10+i,volt_thy+1,rec[5]);
					if(kkk==0)
					{       line(10+i,v375,10+i,volt_thy+1);
						kkk=1;
					}
					else
						kkk=0;
				}
                                VIEW2;
				setcolor(rec[6]);
                                	outtextxy(30,(getmaxy()/2.22-25),"CONDUCTION ANGLE = ");
				outtextxy(10,(getmaxy()/2.24-14.29),"FREE WHEELING ANGLE =");
				cond_ang=0;
				VIEW5;
				f_ang_prn(cond_ang);
				VIEW6;
				f_ang_prn(fwd_ang);
			}
NEXT1 :		c=getch();
                if(c!='n'&&c!='c'&&c!=27&&c!=59&&c!='h')
		goto NEXT1;
NEXT2 :		switch(c)
		{
		case 'n':VIEW3;
			clearviewport();
			setcolor(rec[15]);
			rectangle(0,0,399,479);
			setfillstyle(SOLID_FILL,rec1[15]);
			floodfill(2,2,rec1[15]);
			VIEW2;
			clearviewport();
			setcolor(rec[2]);
			rectangle(0,0,239,249);
			setfillstyle(SOLID_FILL,rec1[14]);
			floodfill(2,2,rec1[2]);
			setcolor(rec[5]);
                         outtextxy(50,(getmaxy()/9.03-7.14),"Vin =");
			outtextxy(50,(getmaxy()/5.38-12.14),"R   =");
			outtextxy(50,(getmaxy()/3.84-17.14),"L   =");
			outtextxy(50,(getmaxy()/2.98-22.14),"Vc  =");
                        setcolor(rec[10]);
			rectangle(0,(getmaxy()/2.26-2.57),239,(getmaxy()*0.51+3.86));
			setfillstyle(SOLID_FILL,rec1[10]);
			floodfill(2,212,rec1[10]);
                        setcolor(rec[1]);
			outtextxy(2,(getmaxy()/2.14-4.57),"PRESS 'h 'OR 'F1' key " );
			outtextxy(2,(getmaxy()/2.14+5.43),"for help screen");
			change=0;
			break;
		case 'c': VIEW3;
			 change=1;
                         setcolor(rec[4]);
			 outtextxy(11,getmaxy()-10,"present scale for current :");
			 xx=222;
			 yy=getmaxy()-10;
			 f_ang_prn(scale_c);
			 size1=imagesize(350,getmaxy()-10,390,getmaxy()-2);
			 buf1=malloc(size1);
			 getimage(350,getmaxy()-10,390,getmaxy()-2,buf1);
			 switch(getch())
			 {
			  case 13:
				  change=2;
				  break;
			  case 'e':putimage(xx-8,yy,buf1,COPY_PUT);
				   val();
				   scale_c=data;
				   VIEW3;
				   clearviewport();
				   setcolor(rec[15]);
				   rectangle(0,0,399,479);
				   setfillstyle(SOLID_FILL,rec1[15]);
				   floodfill(2,2,rec1[15]);
				   break;
			 }
			 break;
		 case 27:
			MOR=0;
			serial(0,'S');
                        if(strcmp(argv[1],"0")==0){

			execl("t.exe","t.exe","0",NULL);}
			else{

			execl("t.exe","t.exe","1",NULL);}
			break;
		 case 59:
		 case 'h':help();
			  change=2;
			  break;
                 default :
		 break;
		 }
	}
}
frame()
{	int i,y;
	int gdriver=DETECT,gmode;
	int circuit[26];
	circuit[0]=170;
	circuit[1]=circuit[3]=ceil(getmaxy()/12.17+0.57);
	circuit[2]=circuit[4]=225;
	circuit[5]=ceil(getmaxy()/7.37-5.14);
	circuit[6]=228;
	circuit[7]=ceil(getmaxy()/7.18-3.86);
	circuit[8]=circuit[12]=circuit[16]=circuit[20]=222;
	circuit[9]=ceil(getmaxy()/6.83-1.29);
	circuit[10]=circuit[14]=circuit[18]=228;
	circuit[11]=ceil(getmaxy()/6.67);
	circuit[13]=ceil(getmaxy()/6.36+2.57);
	circuit[15]=ceil(getmaxy()/6.22+3.86);
	circuit[17]=ceil(getmaxy()/5.96+6.43);
	circuit[19]=ceil(getmaxy()/5.83+7.714);
	circuit[21]=ceil(getmaxy()/5.6+10.29);
	circuit[22]=circuit[24]=225;
	circuit[23]=ceil(getmaxy()/5.49+11.57);
	circuit[25]=ceil(getmaxy()/4.91+12.29);
	detectgraph(&gdriver,&gmode);
	initgraph(&gdriver,&gmode,"c:\\tc\\");
	setgraphmode(gmode);
	cleardevice();
	VIEW1;
	setcolor(rec[1]);
	rectangle(0,0,239,getmaxy()/2.04-5.86);
	setfillstyle(SOLID_FILL,rec1[11]);
	floodfill(2,2,rec1[1]);
	VIEW2;
	setcolor(rec[2]);
	rectangle(0,0,239,getmaxy()*0.51+3.86);
	setfillstyle(SOLID_FILL,rec1[14]);
	floodfill(2,2,rec1[2]);
	setcolor(rec[5]);
	outtextxy(50,(getmaxy()/9.03-7.14),"Vin =");
	outtextxy(50,(getmaxy()/5.38-12.14),"R   =");
	outtextxy(50,(getmaxy()/3.84-17.14),"L   =");
	outtextxy(50,(getmaxy()/2.98-22.14),"Vc  =");
        setcolor(rec[10]);
	rectangle(0,(getmaxy()/2.26-2.57),239,(getmaxy()*0.51+3.86));
	setfillstyle(SOLID_FILL,rec1[10]);
	floodfill(2,212,rec1[10]);
	setcolor(rec[1]);
	outtextxy(2,(getmaxy()/2.14-4.57),"PRESS 'h 'OR 'F1' key " );
	outtextxy(2,(getmaxy()/2.14+5.43),"for help screen");
	VIEW3;
	setcolor(rec[15]);
	rectangle(0,0,399,getmaxy()-1);
	setfillstyle(SOLID_FILL,rec1[15]);
	floodfill(2,2,rec1[15]);
	VIEW1;
	setcolor(rec[5]);
	drawpoly(sizeof(circuit)/(2*sizeof(int)),circuit);
	arc(225,ceil(getmaxy()/4.44+12),270,90,ceil(getmaxy()/140+6.57));
	arc(225,ceil(getmaxy()/3.94+12.29),270,90,ceil(getmaxy()/140+6.57));
	arc(225,ceil(getmaxy()/3.54+12.57),270,90,ceil(getmaxy()/140+6.57));
	arc(225,ceil(getmaxy()/4.18+12.14),90,270,ceil(getmaxy()/280+1.29));
	arc(225,ceil(getmaxy()/3.73+12.43),90,270,ceil(getmaxy()/280+1.29));
	line(225,ceil(getmaxy()/3.29+12.29),225,ceil(getmaxy()/2.92+15.43));
	line(215,ceil(getmaxy()/2.92+15.43),235,ceil(getmaxy()/2.92+15.43));
	line(220,ceil(getmaxy()/2.92+18.43),230,ceil(getmaxy()/2.92+18.43));
	line(225,ceil(getmaxy()/2.92+18.43),225,ceil(getmaxy()/2.8+18.57));
	line(225,ceil(getmaxy()/2.8+18.57),200,ceil(getmaxy()/2.8+18.57));
}
value()
{       VIEW2;
	setcolor(rec[5]);
	outtextxy(50,(getmaxy()/11.2-12.86),"Enter The Parameters...");
	xx=100;
	yy=getmaxy()/9.03-7.14;
	gotoxy(xx,yy);
	val();
	vin=data;
	if(change==3)
	return;
	xx=100;
	yy=(getmaxy()/5.38-12.14);
	gotoxy(xx,yy);
	val();
	r=data;
        if(change==3)
	return;
	xx=100;
	yy=ceil(getmaxy()/3.84-17.14);
	gotoxy(xx,yy);
	val();
	l=data;
        if(change==3)
	return;
	xx=100;
	yy=ceil(getmaxy()/2.98-22.14);
	gotoxy(xx,yy);
	val();
	vc=data;
        if(change==3)
	return;
	xx=30;
	yy=(getmaxy()/2.43-27.143);
	setcolor(rec[0]);
	outtextxy(xx,yy,"FIRING ANGLE = 0");
}
val()
{	char c;
	int COT,i,j,sign,pos,pos1,sig,pos2=0;
	float d[21];
	unsigned size,size1;
	void *buf,*buff;
	size=imagesize(xx,yy,xx+8,yy+7);
	size1=imagesize(xx,yy+7,xx+8,yy+9);
	buf=malloc(size);
	buff=malloc(size1);
	data=0.0;
	for(i=0;i<21;++i)
	d[i]=0.0;
	COT=1;
	sign=+1;
	sig=+1;
	pos=0;
	pos1=0;
	getimage(xx,yy,xx+8,yy+7,buf);
	getimage(xx,yy+7,xx+8,yy+9,buff);
	line(xx,yy+8,xx+8,yy+8);
	while(COT)
	{
	c=getch();
	putimage(xx,yy+7,buff,COPY_PUT);
	switch (c)
	{
	case '0':outtextxy(xx,yy,"0");
		 xx=xx+8;
		 if(sign==-1)
			{data=data+0/pow10(pos);
			pos=pos+1;}
		 else  {
			 data=data*10+0;
			 ++pos2;}
		 for(i=0,j=1;i<=19&&j<=20;++i,++j)
		 d[i]=d[j];
		 d[20]=data;
		 break;
	case '1':outtextxy(xx,yy,"1");
		 xx=xx+8;
		 if(sign==-1)
			{data=data+1/pow10(pos);
			pos=pos+1;}
		 else  {
			 data=data*10+1;
                         ++pos2;}
		 for(i=0,j=1;i<=19&&j<=20;++i,++j)
		 d[i]=d[j];
		 d[20]=data;
		 break;
	case '2':outtextxy(xx,yy,"2");
		 xx=xx+8;
		 if(sign==-1)
			{data=data+2/pow10(pos);
			pos=pos+1;}
		 else    {
			 data=data*10+2;
                         ++pos2;}
		 for(i=0,j=1;i<=19&&j<=20;++i,++j)
		 d[i]=d[j];
		 d[20]=data;
		 break;
	case '3':outtextxy(xx,yy,"3");
		 xx=xx+8;
		 if(sign==-1)
			{data=data+3/pow10(pos);
			pos=pos+1;}
		 else    {
			 data=data*10+3;
                         ++pos2;}
		 for(i=0,j=1;i<=19&&j<=20;++i,++j)
		 d[i]=d[j];
		 d[20]=data;
		 break;
	case '4':outtextxy(xx,yy,"4");
		 xx=xx+8;
		 if(sign==-1)
			{data=data+4/pow10(pos);
			pos=pos+1;}
		 else    {
			 data=data*10+4;
                         ++pos2;}
		 for(i=0,j=1;i<=19&&j<=20;++i,++j)
		 d[i]=d[j];
		 d[20]=data;
		 break;
	case '5':outtextxy(xx,yy,"5");
		 xx=xx+8;
		 if(sign==-1)
			{data=data+5/pow10(pos);
			pos=pos+1;}
		 else    {
			 data=data*10+5;
                         ++pos2;}
		 for(i=0,j=1;i<=19&&j<=20;++i,++j)
		 d[i]=d[j];
		 d[20]=data;
		 break;
	case '6':outtextxy(xx,yy,"6");
		 xx=xx+8;
		 if(sign==-1)
			{data=data+6/pow10(pos);
			pos=pos+1;}
		 else    {
			 data=data*10+6;
                         ++pos2;}
		 for(i=0,j=1;i<=19&&j<=20;++i,++j)
		 d[i]=d[j];
		 d[20]=data;
		 break;
	case '7':outtextxy(xx,yy,"7");
		 xx=xx+8;
		 if(sign==-1)
			{data=data+7/pow10(pos);
			pos=pos+1; }
		 else    {
			 data=data*10+7;
                         ++pos2;}
		 for(i=0,j=1;i<=19&&j<=20;++i,++j)
		 d[i]=d[j];
		 d[20]=data;
		 break;
	case '8':outtextxy(xx,yy,"8");
		 xx=xx+8;
		 if(sign==-1)
			{data=data+8/pow10(pos);
			pos=pos+1;}
		 else    {
			 data=data*10+8;
                         ++pos2;}
		 for(i=0,j=1;i<=19&&j<=20;++i,++j)
		 d[i]=d[j];
		 d[20]=data;
		 break;
	case '9':outtextxy(xx,yy,"9");
		 xx=xx+8;
		 if(sign==-1)
			{data=data+9/pow10(pos);
			pos=pos+1;}
		 else    {
			 data=data*10+9;
                         ++pos2;}
		 for(i=0,j=1;i<=19&&j<=20;++i,++j)
		 d[i]=d[j];
		 d[20]=data;
		 break;
	case '.':outtextxy(xx,yy,".");
		 xx=xx+8;
		 sign=-1;
		 pos=1;
		 break;
	case '-':outtextxy(xx,yy,"-");
		 xx=xx+8;
		 ++pos1;
		 sig=-2;
		 break;
	case 83:if(pos1!=0&&pos==0&&pos2==0)
		--pos1;
		if(pos1==1)
		sig=-2;
		else
		sig=1;
		if(pos2!=0&&pos==0)
		--pos2;
		if(pos!=0)
		--pos;
		if(pos==0)
		sign=1;
		 xx=xx-8;
		 putimage(xx,yy,buf,COPY_PUT);

		 data=d[19];
		 d[20]=data;
		 for(i=19,j=18;i>=1&&j>=0;--i,--j)
		 d[i]=d[j];
		 d[0]=0.0;
		 break;

	case 75: xx=xx-8;
		 break;
	case 77:xx=xx+8;
		break;
	case 27:
		COT=0;
		change=3;
		serial(0,'S');
                if(cg==0)
			execl("t.exe","t.exe","0",NULL);
			else
			execl("t.exe","t.exe","1",NULL);
		break;
	case 13:
	case 'a':COT=0;
		 break;
	case 59:
	case 'h':help();
		 VIEW2;
		 COT=1;
		 break;
	}
	line(xx,yy+8,xx+8,yy+8);
	}
	putimage(xx,yy+7,buff,COPY_PUT);
	if(sig==-2){
	data=(-1)*data;
	sig=+1;}

}


arrowpos(int kk)
{	int CONT=1,fire;
	char c;
	unsigned size;
	void *buf;
	size=imagesize(2+kk,v110,370,v110+12);
	buf=malloc(size);
	setcolor(rec[4]);
	if(change==1){
	drawpoly(5,arrow);
	return;}
	arrow[0]=10+kk;
	arrow[1]=(getmaxy()/5.28+29.14);
	arrow[2]=10+kk;
	arrow[3]=(getmaxy()/5.28+20.14);
	arrow[4]=5+kk;
	arrow[5]=(getmaxy()/5.28+25.14);
	arrow[6]=15+kk;
	arrow[7]=(getmaxy()/5.28+25.14);
	arrow[8]=10+kk;
	arrow[9]=(getmaxy()/5.28+20.14);
	getimage(5+kk,v110,360,v110+10,buf);
	drawpoly(5,arrow);
	while(CONT)
	{	c=getch();
		switch(c)
		{
		case 75:setcolor(rec1[15]);
			drawpoly(5,arrow);
			setcolor(rec[4]);
			arrow[0]=arrow[0]-1;
			arrow[2]=arrow[2]-1;
			arrow[4]=arrow[4]-1;
			arrow[6]=arrow[6]-1;
			arrow[8]=arrow[8]-1;
			putimage(5+kk,v110,buf,COPY_PUT);
			drawpoly(5,arrow);
			f_angle=arrow[0]-10;
			fire=f_angle-kk;
			VIEW4;
			f_ang_prn(fire);
			VIEW3;
			break;
		case 77:setcolor(rec1[15]);
			drawpoly(5,arrow);
			setcolor(rec[4]);
			arrow[0]=arrow[0]+1;
			arrow[2]=arrow[2]+1;
			arrow[4]=arrow[4]+1;
			arrow[6]=arrow[6]+1;
			arrow[8]=arrow[8]+1;
			putimage(5+kk,v110,buf,COPY_PUT);
                        drawpoly(5,arrow);
			f_angle=arrow[0]-10;
                        fire=f_angle-kk;
			VIEW4;
			f_ang_prn(fire);
			VIEW3;
			break;
		case 13:
		case'a':CONT=0;
			f_angle=arrow[0]-10;
			break;
		case 59:
		case'h':help();
			 VIEW3;
			 CONT=1;
			 break;
		}
	}
  }

f_ang_prn(ang)
{       int x[3],i,c;
	if(change!=1)
	{
	clearviewport();
	setcolor(rec[14]);
	rectangle(0,0,50,(getmaxy()/140+6.57));
	setfillstyle(SOLID_FILL,rec[14]);
	floodfill(2,2,rec[14]);
	xx=2;
	yy=0;
	setcolor(rec1[0]);
	}
	x[0]=ang/100;
	x[1]=ang/10-x[0]*10;
	x[2]=ang-x[0]*100-x[1]*10;
	if(x[0]==0)
		{	x[0]=10;
			if (x[1]==0)
				{	x[1]=10;
				}
		}
	for(i=0;i<3;i++)
	{
	c=x[i];
	switch (c)
	{
	case 0	:outtextxy(xx,yy,"0");
		 xx=xx+8;
		 break;
	case 1	:outtextxy(xx,yy,"1");
		 xx=xx+8;
		 break;
	case 2  :outtextxy(xx,yy,"2");
		 xx=xx+8;
		 break;
	case 3	:outtextxy(xx,yy,"3");
		 xx=xx+8;
		 break;
	case 4	:outtextxy(xx,yy,"4");
		 xx=xx+8;
		 break;
	case 5	:outtextxy(xx,yy,"5");
		 xx=xx+8;
		 break;
	case 6	:outtextxy(xx,yy,"6");
		 xx=xx+8;
		 break;
	case 7	:outtextxy(xx,yy,"7");
		 xx=xx+8;
		 break;
	case 8	:outtextxy(xx,yy,"8");
		 xx=xx+8;
		 break;
	case 9	:outtextxy(xx,yy,"9");
		 xx=xx+8;
		 break;
	case 10	:outtextxy(xx,yy," ");
		 xx=xx+8;
		 break;
	 }
	 }
}
void help()
{
char c;
int i;
i=1;
VIEW1;
clearviewport();
rectangle(0,0,239,(getmaxy()/2.04)-5.86);
setfillstyle(SOLID_FILL,rec1[11]);
floodfill(2,2,rec1[1]);
setcolor(rec[5]);
outtextxy(10,getmaxy()/70-1.86,"1)press Esc ==> To Quit");
outtextxy(10,getmaxy()/56+6.43,"2)press 'c' followed by 'e' ");
outtextxy(10,getmaxy()/40+13,"  to change the scale factor");
outtextxy(10,getmaxy()/31.11+19.57,"  of current,otherwise press");
outtextxy(10,getmaxy()/25.45+26.14,"  Enter.");
outtextxy(10,getmaxy()/21.54+32.71,"3)press 'a' OR 'Enter'==> to");
outtextxy(10,getmaxy()/18.67+39.29,"  place cursor on next data");
outtextxy(10,getmaxy()/16.47+45.86,"  entry point.");
outtextxy(10,getmaxy()/14.74+52.43,"4)use 'Keys <--and-->' to ");
outtextxy(10,getmaxy()/13.33+59,"  select  firing angle ");
outtextxy(10,ceil(getmaxy()/23.32+84.42),"  position. ");
while(i==1){
c=getch();
switch(c){
case 59:
case 'h':clearviewport();
	 rectangle(0,0,239,(getmaxy()/2.04)-5.86);
	 setfillstyle(SOLID_FILL,rec1[11]);
	 floodfill(2,2,rec1[1]);
	 setcolor(rec[5]);
	 outtextxy(10,getmaxy()/70-1.86,"5)press 'a' OR 'Enter' ");
	 outtextxy(10,getmaxy()/56+6.43," ==> after selecting proper");
	 outtextxy(10,getmaxy()/40+13,"     firing angle position.");
	 outtextxy(10,getmaxy()/31.11+19.57,"6)press 'n'==> to enter ");
	 outtextxy(10,getmaxy()/25.45+26.14,"               new data .");
	 outtextxy(10,getmaxy()/21.54+32.71,"7)press 'DEL' to remove");
	 outtextxy(10,getmaxy()/18.67+39.29,"  data entry .");
	 break;
case 27: clearviewport();
	 i=0;
	 break;
	 }
}
putimage(0,0,buf3,COPY_PUT);
}
serial(int x,int ch)
{
int y;
char c;
	y=0xa7;
	bioscom(0,y,0);
	for(;;){
	if(kbhit()){
	c=getch();
	      }
	 switch(c){
	 case 't':goto NEXT;
	  default:
	bioscom(1,ch,0);
	}
	}
	NEXT:   if(ch=='R'||ch=='S')
	goto OUT;
	for(;;){
	if(kbhit()){
	c=getch();
	      }
	 switch(c){
	 case 'a':goto OUT;
	  default:
	bioscom(1,x,0);
	}
	}
OUT: return;
}