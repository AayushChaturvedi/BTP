NEXT:   if(ch=='R'||ch=='S')
	goto OUT;