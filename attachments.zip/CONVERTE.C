# include <graphics.h>
# include <conio.h>
# include <stdio.h>
#include<process.h>
#include<bios.h>
# define LS setlinestyle(SOLID_LINE,0,THICK_WIDTH);
# define TS1 settextstyle(SANS_SERIF_FONT,HORIZ_DIR,1);
# define TS2 settextstyle(DEFAULT_FONT,HORIZ_DIR,1);
# define TS3 settextstyle(DEFAULT_FONT,HORIZ_DIR,2);
# define VIEW setviewport(1,1,getmaxx()-1,getmaxy()-1,1);
int rec[16],rec1[16],cg;
main()
{
int gdriver,gmode;
int c,i;
system("cls");
printf("\n\n\n\n\n\n\n\t---------------------------------------------------------------");
printf("\n\n\n\t\tenter 0 if you are using color monitor\n");
printf("\t\t\totherwise press any digit\n\n\n ");
printf("\t--------------------------------------------------------------\n\n\n\t\t\t\t");
scanf("%d", &cg);
detectgraph(&gdriver,&gmode);
initgraph(&gdriver,&gmode,"c:\\tc\\");
if(cg==0){
for(i=0;i<16;++i){
rec[i]=rec1[i]=i;  }
}
else{
for(i=0;i<16;++i){
rec[i]=0;
rec1[i]=15; }
}
LS;
setcolor(rec[1]);
rectangle(8,8,635,(getmaxy()/3)+35);
setfillstyle(SOLID_FILL,rec1[15]);
floodfill(605,(getmaxy()/3)+20,rec1[1]);
setcolor(rec[0]);
rectangle(15,15,624,(getmaxy()/3)+24);
setcolor(rec[4]);
rectangle(20,(getmaxy()/28)+3,619,(getmaxy()/3)+19);
TS3;
outtextxy(120,(getmaxy()/14+5.71),"DEMONSTRATION  SOFTWARE");
outtextxy(255,(getmaxy()/7+11.43)," FOR");
outtextxy(80,(getmaxy()/4.67+17.14),"CONVERTOR  CIRCUIT  WAVEFORMS");
sleep(1);
bioscom(0,0xa7,0);
if(cg==0)
execl("cont.exe","cont.exe","0",NULL);
else
execl("cont.exe","cont.exe","1",NULL);
}
