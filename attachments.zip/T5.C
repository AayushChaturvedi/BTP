	current=-vc/r+(i_fnl+vc/r)*exp(-(j-pi)/wtau);
							fwd_ang=angle-180;