#include<stdlib.h>
#include<graphics.h>
#include<stdio.h>
main()
{
double r1;
char *buf;
int gd,gm;
detectgraph(&gd,&gm);
initgraph(&gd,&gm,"c:\\tc\\");
r1=3.3*4;
moveto(20,20);
printf("%f", r1);
line(100,200,200,20);
moveto(100,100);
scanf("%f",&r1);
gcvt(r1,4,buf);
outtextxy(20,30,buf);
getch();
}