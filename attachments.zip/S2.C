xxx=f_angle*pow(10,3)/18;
		f_angle_lb=(0x00ff)&(xxx);
		f_angle_hb=(0xff00)&(xxx);
		serial(f_angle_lb,'g');
		serial(f_angle_hb,'g');
		serial(0,'r');