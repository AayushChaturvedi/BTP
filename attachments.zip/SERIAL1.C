#include<dos.h>
#include<stdio.h>
#include<stdlib.h>
#include<bios.h>
#include<conio.h>
int x,y,z,ch;
main()
	{
		x=0xa7;
		bioscom(0,x,0);
		bioscom(3,y,0);
		printf("\n %x     %x",x,y);
		ch='A';
		for(;;)
		{
		ch=getch();
		if(ch=='s')
		break;
		bioscom(1,ch,0);}
}

